# Project: Toxic Comment Filtering
**Organization:** NewtonAI Technologies  
**Student/Candidate:** Tanaya Pawar  
**Submission Deadline:** August 21, 2026  
**Email:** projects@newtonai.tech  

---

## Project Overview
Develop and demonstrate a multi-label toxicity classifier for a gaming platform’s live chat. The system flags messages as spam, insult, profanity, hate speech, or non-toxic, assigns a 0-5 severity score, and outputs recommended moderation actions.

## Mitigation Strategies & Severity Matrix (0-5 Scale)
- **Score 0 (Non-Toxic):** Allow message in live chat feed.
- **Score 1–2 (Low Severity / Spam):** Soft Warning prompt displayed to the user.
- **Score 3–4 (Medium Severity / Insult & Profanity):** Temporary Chat Mute (5 Minutes).
- **Score 5 (High Severity / Hate Speech & Severe Toxic):** Automated permanent or session Ban (`AUTO-BAN`).

## Repository Structure
- `toxic_filter.py`: Core preprocessing, model training, and evaluation logic.
- `app.py`: Streamlit interactive dashboard script.
- `data/detection_output.csv`: Sample chat logs and detection output logs.
- `models/`: Serialized joblib model artifacts.
- `notebooks/`: Jupyter notebook demo.
