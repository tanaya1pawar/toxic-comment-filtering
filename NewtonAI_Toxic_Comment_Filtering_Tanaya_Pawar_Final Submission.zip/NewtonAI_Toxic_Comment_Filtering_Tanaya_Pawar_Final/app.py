import streamlit as st
from joblib import load
import os

st.set_page_config(page_title="NewtonAI - Toxic Comment Filter", page_icon="🛡️", layout="centered")

st.title("🛡️ NewtonAI: Live Chat Toxicity Filter")
st.markdown("Gaming Platform Real-Time Moderation & Severity Scoring Dashboard")

@st.cache_resource
def load_assets():
    try:
        vec = load('models/tfidf_vectorizer.joblib')
        clf = load('models/toxic_model.joblib')
    except:
        from toxic_filter import build_and_train_model
        vec, clf = build_and_train_model()
    return vec, clf

vectorizer, classifier = load_assets()
from toxic_filter import evaluate_message

chat_input = st.text_input("Simulate Live Chat Message:", placeholder="Type a gaming chat message here...")

if st.button("Analyze Message"):
    if chat_input.strip() == "":
        st.warning("Please enter a valid chat message.")
    else:
        res = evaluate_message(chat_input, vectorizer, classifier)
        st.subheader("Analysis Results")
        st.write(f"**Original Text:** {res['original_text']}")
        st.write(f"**Detected Labels:** {res['labels'] if res['labels'] else ['Non-Toxic']}")
        st.metric(label="Severity Score (0-5)", value=f"{res['severity_score']} / 5")
        
        action = res['recommended_action']
        if "ALLOW" in action:
            st.success(f"Action: {action}")
        elif "WARNING" in action:
            st.warning(f"Action: {action}")
        else:
            st.error(f"Action: {action}")
