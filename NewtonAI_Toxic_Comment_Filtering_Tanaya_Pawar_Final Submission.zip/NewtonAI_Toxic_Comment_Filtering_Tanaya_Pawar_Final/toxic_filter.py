import re
import string
import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.multiclass import OneVsRestClassifier
from sklearn.linear_model import LogisticRegression
from joblib import dump, load

CONTRACTIONS = {
    "ain't": "am not", "aren't": "are not", "can't": "cannot", "c'mon": "come on",
    "didn't": "did not", "doesn't": "does not", "don't": "do not", "gonna": "going to",
    "gotta": "got to", "isn't": "is not", "it's": "it is", "that's": "that is",
    "there's": "there is", "they're": "they are", "wasn't": "was not", "weren't": "were not",
    "what's": "what is", "won't": "will not", "wouldn't": "would not", "you're": "you are"
}

def clean_gaming_chat(text):
    if pd.isna(text):
        return ""
    text = text.lower()
    text = re.sub(r'[^\w\s.,!?_-]', '', text)
    words = text.split()
    expanded_words = [CONTRACTIONS.get(word, word) for word in words]
    text = " ".join(expanded_words)
    text = re.sub(r'(.)\1{2,}', r'\1\1', text)
    return text

def build_and_train_model():
    print("Initializing training routine with Jigsaw-style schema...")
    data = {
        'comment_text': [
            "you are absolute trash get off the game u nub",
            "gg well played everyone that was fun",
            "idiot hacker stop aimbotting or else ill kill u",
            "buy cheap gold coins at spamsite.com now!!",
            "shut up u worthless piece of trash uninstall",
            "nice match team lets go next round",
            "die u worthless trash hacker trash"
        ],
        'spam': [0, 0, 0, 1, 0, 0, 0],
        'insult': [1, 0, 1, 0, 1, 0, 1],
        'profanity': [1, 0, 1, 0, 1, 0, 1],
        'hate_speech': [0, 0, 1, 0, 0, 0, 1],
        'severe_toxic': [0, 0, 1, 0, 1, 0, 1]
    }
    df = pd.DataFrame(data)
    df['clean_text'] = df['comment_text'].apply(clean_gaming_chat)
    
    X = df['clean_text']
    y = df[['spam', 'insult', 'profanity', 'hate_speech', 'severe_toxic']]
    
    vectorizer = TfidfVectorizer(max_features=5000, ngram_range=(1, 2))
    X_vec = vectorizer.fit_transform(X)
    
    classifier = OneVsRestClassifier(LogisticRegression(class_weight='balanced'))
    classifier.fit(X_vec, y)
    
    print("Model training completed successfully.")
    return vectorizer, classifier

def evaluate_message(text, vectorizer, model):
    cleaned = clean_gaming_chat(text)
    vec = vectorizer.transform([cleaned])
    preds = model.predict(vec)[0]
    probs = model.predict_proba(vec)[0]
    
    active_labels = [model.classes_[i] for i, val in enumerate(preds) if val == 1]
    max_prob = max(probs) if len(probs) > 0 else 0.0
    base_score = len(active_labels)
    
    if 'severe_toxic' in active_labels or 'hate_speech' in active_labels:
        severity_score = min(5, int(round(3 + (max_prob * 2))))
    elif base_score > 0:
        severity_score = min(3, int(round(1 + (max_prob * 2))))
    else:
        severity_score = 0
        
    if severity_score == 0:
        action = "ALLOW"
    elif 1 <= severity_score <= 2:
        action = "WARNING (Soft Alert)"
    elif 3 <= severity_score <= 4:
        action = "MUTE USER (5 Minutes)"
    else:
        action = "AUTO-BAN (Severe Policy Breach)"
        
    return {
        "original_text": text,
        "labels": active_labels,
        "severity_score": severity_score,
        "recommended_action": action
    }

if __name__ == "__main__":
    vec, clf = build_and_train_model()
    dump(vec, 'models/tfidf_vectorizer.joblib')
    dump(clf, 'models/toxic_model.joblib')

    print("Saved trained model artifacts.")
